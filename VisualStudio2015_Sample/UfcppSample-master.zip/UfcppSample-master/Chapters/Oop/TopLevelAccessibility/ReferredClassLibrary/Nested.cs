﻿public class TopLevelClass
{
    public class PublicClass { }
    protected class ProtectedClass { }
    protected internal class ProtectedInternalClass { }
    internal class InternalClass { }
    private class PrivateClass { }
}
