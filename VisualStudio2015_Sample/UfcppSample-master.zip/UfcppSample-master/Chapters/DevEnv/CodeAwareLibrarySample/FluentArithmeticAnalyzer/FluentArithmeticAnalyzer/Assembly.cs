﻿[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("FluentArithmeticAnalyzer.Test")]
