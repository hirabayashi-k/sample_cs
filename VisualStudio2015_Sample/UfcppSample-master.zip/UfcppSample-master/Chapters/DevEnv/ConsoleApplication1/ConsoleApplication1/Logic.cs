﻿namespace ConsoleApplication1
{
    class Logic
    {
        public int Filter(int x) => x * x;
    }
}
