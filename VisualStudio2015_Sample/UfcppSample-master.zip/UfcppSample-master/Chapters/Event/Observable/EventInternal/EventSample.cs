﻿namespace Observable.EventInternal
{
    using System;

    /// <summary>
    /// 自動実装。
    /// </summary>
    class EventSample
    {
        public event EventHandler X;
    }
}
